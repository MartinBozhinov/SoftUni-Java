package com.example.xmlprocexe;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class XmlProcExeApplicationTests {

    @Test
    void contextLoads() {
    }

}
