package com.example.xmlprocexe.util;

public interface ValidationUtil {

    <T> boolean isValid(T entity);
}
