package com.example.xmlprocexe;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class XmlProcExeApplication {

    public static void main(String[] args) {
        SpringApplication.run(XmlProcExeApplication.class, args);
    }

}
