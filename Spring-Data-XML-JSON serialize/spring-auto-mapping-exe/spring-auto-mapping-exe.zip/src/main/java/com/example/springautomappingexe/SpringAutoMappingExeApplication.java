package com.example.springautomappingexe;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringAutoMappingExeApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringAutoMappingExeApplication.class, args);
    }

}
