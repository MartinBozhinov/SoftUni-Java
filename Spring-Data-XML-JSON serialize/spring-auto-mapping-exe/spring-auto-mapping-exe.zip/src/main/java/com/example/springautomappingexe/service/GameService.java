package com.example.springautomappingexe.service;

import com.example.springautomappingexe.entity.GameAddDto;

public interface GameService {


    void addGame(GameAddDto gameAddDto);

}
