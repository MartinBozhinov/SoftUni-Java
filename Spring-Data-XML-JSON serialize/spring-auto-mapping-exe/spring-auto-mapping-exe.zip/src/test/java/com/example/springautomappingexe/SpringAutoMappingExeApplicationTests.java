package com.example.springautomappingexe;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringAutoMappingExeApplicationTests {

    @Test
    void contextLoads() {
    }

}
