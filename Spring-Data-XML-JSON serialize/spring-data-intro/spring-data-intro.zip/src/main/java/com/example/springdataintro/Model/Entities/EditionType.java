package com.example.springdataintro.Model.Entities;

public enum EditionType {
    NORMAL, PROMO, GOLD
}
