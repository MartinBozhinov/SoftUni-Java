package com.example.springdataintro.Model.Entities;

public enum AgeRestriction {
    MINOR, TEEN, ADULT
}
