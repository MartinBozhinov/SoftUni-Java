package animals;



public class Kittens extends Cat {
    private static final String gender = "Female";


    public Kittens(String name, int age) {
        super(name, age, gender);
    }

    public String produceSound(){
        return "Meow";
    }
}
