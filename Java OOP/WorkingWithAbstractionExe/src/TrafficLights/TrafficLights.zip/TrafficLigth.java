package TrafficLights;

public enum TrafficLigth {
    RED,
    GREEN,
    YELLOW,
}
